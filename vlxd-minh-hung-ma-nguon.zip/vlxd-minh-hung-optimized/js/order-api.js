/* Giữ nguyên địa chỉ triển khai Google Apps Script hiện có. */
(function (app) {
    'use strict';
    const API_URL = 'https://script.google.com/macros/s/AKfycbxLfpE3x0EWOPv6LF-6eopRUTKVf_KvQ0sB3LN0EEPorOMZNZq24zE8oQ2FYX4XThUl1w/exec';

    async function request(query = '', options = {}) {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 25000);
        try {
            const response = await fetch(API_URL + query, {...options, signal: controller.signal, cache: 'no-store'});
            if (!response.ok) throw new Error('Không kết nối được nơi lưu hóa đơn. Vui lòng thử lại.');
            const text = await response.text();
            let data;
            try { data = JSON.parse(text); } catch {
                if (options.method === 'POST' && /^(success|ok|đã lưu)(?:[.!\s]*)$/i.test(text.trim())) return {success: true};
                throw new Error(options.method === 'POST'
                    ? 'Chưa nhận được xác nhận từ nơi lưu hóa đơn. Vui lòng kiểm tra trước khi lưu lại.'
                    : 'Chưa đọc được dữ liệu hóa đơn. Vui lòng kiểm tra nơi lưu dữ liệu rồi bấm Làm mới.');
            }
            if (data === false || data == null || (data && (data.success === false || data.error || data.status === 'error'))) {
                throw new Error('Nơi lưu hóa đơn báo lỗi. Vui lòng kiểm tra và thử lại.');
            }
            return data;
        } catch (error) {
            if (error.name === 'AbortError') throw new Error(options.method === 'POST'
                ? 'Kết nối quá lâu, chưa xác nhận được kết quả lưu. Vui lòng kiểm tra hóa đơn đã lưu chưa trước khi thử lại.'
                : 'Kết nối quá lâu. Vui lòng thử lại.');
            throw error;
        } finally { clearTimeout(timeout); }
    }

    async function list() {
        const data = await request('?action=list');
        const orders = Array.isArray(data) ? data : data && data.orders;
        if (!Array.isArray(orders)) {
            const error = new Error('Chưa lấy được lịch sử hóa đơn. Cần cập nhật chức năng đọc danh sách ở nơi lưu dữ liệu, sau đó bấm Làm mới.');
            error.code = 'HISTORY_UNAVAILABLE';
            throw error;
        }
        return orders.map(app.Data.normalizeOrder);
    }

    async function save(order) {
        const result = await request('', {
            method: 'POST', headers: {'Content-Type': 'text/plain;charset=utf-8'}, body: JSON.stringify(order)
        });
        // Nếu máy chủ cấp mã chính thức, dùng mã đó thay cho mã xem trước.
        const raw = result && (result.order || (result.data && result.data.id ? result.data : null));
        if (raw && typeof raw === 'object' && !Array.isArray(raw) && raw.id) return {...order, ...raw};
        if (result && result.id) return {...order, id: result.id};
        const acknowledged = result && (result.success === true ||
            /^(success|ok)$/i.test(String(result.status || result.result || '')));
        if (acknowledged || (typeof result === 'string' && /^(success|ok)$/i.test(result))) return order;
        throw new Error('Chưa xác nhận được kết quả lưu. Vui lòng kiểm tra hóa đơn đã được lưu chưa trước khi thử lại.');
    }

    async function nextId(orders) {
        let lastId = '';
        try { const data = await request(); lastId = String(data && data.lastId || ''); } catch { /* Dùng danh sách đã tải để xem trước. */ }
        const [year, month, day] = app.Data.todayKey().split('-');
        const prefix = `HD${day}${month}${year}`;
        const ids = [lastId, ...orders.map(order => order.id)];
        const sequence = ids.reduce((max, id) => {
            const suffix = String(id).startsWith(prefix) ? String(id).slice(prefix.length) : '';
            return /^\d+$/.test(suffix) ? Math.max(max, Number(suffix)) : max;
        }, 0);
        return prefix + String(sequence + 1).padStart(4, '0');
    }

    app.API = {list, save, nextId};
}(window.InvoiceApp));
