(function (app) {
    'use strict';
    const {normalizeOrder, formatDate, formatMoney, escapeHtml: html} = app.Data;
    function print(raw) {
        const order = normalizeOrder(raw);
        const fields = {p_id: order.id, p_date: 'Ngày ' + formatDate(order.date), p_name: order.customer,
            p_address: order.address, p_total: formatMoney(order.total), p_paid: formatMoney(order.paid),
            p_debt: formatMoney(order.debt), p_shipper: order.shipper};
        Object.entries(fields).forEach(([id, value]) => { document.getElementById(id).textContent = value; });
        document.getElementById('p_table').innerHTML = order.items.map((item, index) => `<tr>
            <td>${index + 1}</td><td>${html(item.name)}</td><td>${html(item.unit || '—')}</td><td>${html(item.qty)}</td>
            <td>${html(formatMoney(item.price))}</td><td>${html(formatMoney(item.subtotal))}</td></tr>`).join('');
        window.print();
    }
    app.Print = {print};
}(window.InvoiceApp));
