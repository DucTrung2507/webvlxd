# Cập nhật ba file Apps Script đang dùng

Giữ ba file trong cùng dự án Apps Script. Thay nội dung từng file bằng bản tương ứng ở thư mục này:

| File trên Google | Bản mới | Chức năng |
| --- | --- | --- |
| `websang.gs` | [websang.gs](websang.gs) | API cho website, đọc lịch sử và lưu hóa đơn |
| `luuin.gs` | [luuin.gs](luuin.gs) | Các nút lưu, lưu và in, tạo đơn mới trên tab `IN` |
| `soHD.gs` | [soHD.gs](soHD.gs) | Tạo mã dự kiến vào ô `IN!B5` |

Các tên hàm gán cho nút hiện tại được giữ: `luuHoaDon`, `luuVaInHoaDon`, `taoHD`, `taoSoHoaDonTuDong`. Phần cấu hình và hàm dùng chung `generateId` chỉ khai báo ở `websang.gs`; hai file còn lại gọi lại chúng. Các file `.gs` trong một dự án dùng chung phạm vi toàn cục, nên không chép thêm bản sao của các hàm này vào file khác.

Nếu đã thêm `Code.gs` theo hướng dẫn trước, chỉ giữ một bản phần web tại `websang.gs`; bỏ phần trùng trong `Code.gs`. Mẫu `ListOrders.gs` trước đây cũng không cần dùng. Không gộp đè toàn bộ ba file vào một file rồi để lại các hàm cũ.

## Vì sao cần sửa cả ba file

Mã cũ của bạn ghi chi tiết theo hai cấu trúc khác nhau:

| Nguồn tạo đơn cũ | Cột A đến F trong `CHITIET_HD` |
| --- | --- |
| Website (`websang.gs`) | mã hóa đơn, tên hàng, số lượng, đơn vị tính, đơn giá, thành tiền |
| Tab `IN` (`luuin.gs`) | mã hóa đơn, tên hàng, số lượng, đơn giá, thành tiền; F trống |

Bản đọc mới nhận cả hai dạng theo dữ liệu từng dòng, tránh lệch đơn giá và thành tiền khi xem hóa đơn cũ. Dòng có F (kể cả giá trị 0) được đọc theo sáu cột. Dòng F trống và D/E đều là số tiền được đọc theo dạng năm cột cũ. Dòng sáu cột thiếu thành tiền được tính từ số lượng × đơn giá nếu nhận dạng được. Các dòng dữ liệu cũ không được ghi lại hay di chuyển tự động.

Từ bản mới, cả website và tab `IN` đều ghi sáu cột. Vì mã bạn gửi chưa xác định ô đơn vị tính trong tab `IN`, đơn lưu từ tab này để trống ĐVT; không tự đoán vị trí ô trong mẫu in. Nếu ĐVT của dòng cũ là số và F bị thiếu thì dữ liệu có thể mơ hồ giữa hai cấu trúc; cần đối chiếu dòng đó trong Sheet.

Cả hai nguồn lưu dùng cùng khóa script để kiểm tra mã và ghi dữ liệu. Mã dự kiến được sinh từ số thứ tự lớn nhất của các mã cùng ngày, thay cho việc đếm riêng ô ngày dạng `Date`. Nếu mã đang nằm trong `IN!B5` đã được nguồn khác sử dụng, thao tác lưu sẽ báo trùng; tạo mã mới trước khi lưu tiếp.

## Đưa mã lên Google

1. Mở đúng dự án Apps Script gắn với file Sheets đang dùng. Thay nội dung **cả ba file** theo bảng trên rồi lưu. Không đổi tên các hàm gán cho nút.
2. Chọn **Deploy → Manage deployments**, chọn Web app có URL `/exec` đang cấu hình trong website, bấm sửa, chọn **New version**, rồi **Deploy**. Giữ cấu hình quyền truy cập hiện tại. Cập nhật deployment đang có để giữ nguyên URL.
3. Mở URL `/exec?action=list`. Phản hồi phải có dạng `{ "orders": [...] }`; không chỉ có `API OK` hoặc `lastId`. Mỗi hóa đơn có `items` ghép từ `CHITIET_HD` theo mã.
4. Trở lại website, bấm **Làm mới**. Để trống hai ngày để xem toàn bộ lịch sử; chọn **Từ ngày / Đến ngày** và bấm **Tìm kiếm** để lọc, bao gồm cả hai ngày mốc.
5. Đối chiếu một hóa đơn cũ tạo trên website và một hóa đơn cũ tạo từ tab `IN`, đặc biệt đơn giá và thành tiền.

Sửa mã trong trình soạn thảo chưa cập nhật Web app đã triển khai; cần thực hiện bước 2. Các thao tác trên tab `IN` sử dụng mã hiện đã lưu trong dự án.

## Cấu trúc dữ liệu và phạm vi

Bảng tính vẫn là `1TfROVVl8D3d3UpbwvNADxg7elcCUmbgQZMfTQi8IyQw`:

- `HOADON`: `id`, `date`, `customer`, `address`, `total`, `paid`, `debt`, `shipper`.
- `CHITIET_HD` cho đơn lưu mới: `id`, `name`, `qty`, `unit`, `price`, `subtotal`.
- `IN`: giữ các vùng nhập và vùng xuất PDF `A1:G32` của mã bạn gửi.

`GET ?action=list` chỉ đọc toàn bộ hai tab dữ liệu; hóa đơn thiếu mặt hàng vẫn xuất hiện với `items: []`. Ô ngày dạng `Date` được chuyển theo múi giờ Việt Nam, chuỗi ngày cũ được giữ để website xử lý. GET không có `action` trả `{ "lastId": "..." }`. POST trả mã chính thức `{ "status": "success", "id": "..." }` để website hiển thị và in đúng mã đã lưu.

Các file ở đây là bản cục bộ, chưa được triển khai lên Google và chưa sửa dữ liệu đang lưu. Không cần tạo tab mới hoặc xóa hóa đơn cũ.

Tài liệu Google: [phạm vi toàn cục của các file Apps Script](https://developers.google.com/apps-script/guides/v8-runtime), [khóa khi nhiều yêu cầu chạy cùng lúc](https://developers.google.com/apps-script/reference/lock/lock-service), [hộp thoại và việc tạm dừng script](https://developers.google.com/apps-script/reference/base/ui), [cập nhật deployment](https://developers.google.com/apps-script/concepts/deployments#edit_a_versioned_deployment).
