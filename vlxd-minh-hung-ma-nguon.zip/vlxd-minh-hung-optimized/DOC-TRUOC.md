# Thông tin tiếp tục công việc VLXD Minh Hùng

Website dùng HTML, CSS và JavaScript thuần. File vào là index.html; không có bước build.
Mã nguồn này được chuẩn bị trong VS Code ở máy người dùng. Chưa có địa chỉ hosting website được xác nhận.

Mục tiêu: trang index hiển thị toàn bộ hóa đơn đã lưu, tìm từ ngày đến ngày (bao gồm hai ngày mốc), giữ việc tạo/lưu/in hóa đơn.

Google Sheet:
https://docs.google.com/spreadsheets/d/1TfROVVl8D3d3UpbwvNADxg7elcCUmbgQZMfTQi8IyQw/edit
Các tab: HOADON, CHITIET_HD và mẫu nhập/in IN.

Mã website đã có giao diện và bộ lọc. js/order-api.js chứa URL Apps Script hiện dùng; GET ?action=list cần trả {orders:[...]}.
Ba bản Apps Script đã chuẩn bị trong apps-script/: websang.gs, luuin.gs, soHD.gs. Đọc apps-script/README.md để biết chính xác các cột, điểm cần giữ và cách triển khai.
Lịch sử CHITIET_HD có thể trộn dòng 5 cột từ mẫu IN và 6 cột từ website; phần đọc đã xử lý hai dạng. Không cần tự chuyển lại dữ liệu cũ để nối website.

Trạng thái: đã sửa và kiểm thử mã cục bộ bằng dịch vụ Google mô phỏng. Chưa xác nhận các file này đã được cập nhật/triển khai trong tài khoản Google. Chưa kiểm thử trình duyệt hoặc lưu vào Sheet thật.

Bước cần tiếp tục: dùng kết nối Google để kiểm tra các tab thực tế và khả năng truy cập dự án Apps Script. Nếu công cụ hỗ trợ sửa/triển khai Apps Script, dùng ba file đã chuẩn bị và kiểm tra GET ?action=list. Nếu công cụ chỉ hỗ trợ Sheet/Drive, nêu rõ giới hạn và hướng dẫn đúng phần cập nhật Apps Script cần người dùng làm. Giữ cấu hình quyền truy cập hiện có.
