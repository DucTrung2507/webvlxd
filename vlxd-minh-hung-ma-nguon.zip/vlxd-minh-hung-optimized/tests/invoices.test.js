/* Chạy từ thư mục dự án bằng JavaScriptCore (macOS). */
var window = {};
var elements = {};
var domReady;
var document = {
    getElementById: function (id) {
        if (!elements[id]) elements[id] = {
            value: '', textContent: '', innerHTML: '', hidden: false, disabled: false,
            listeners: {}, attributes: {},
            addEventListener: function (type, fn) { this.listeners[type] = fn; },
            setAttribute: function (name, value) { this.attributes[name] = value; },
            removeAttribute: function (name) { delete this.attributes[name]; },
            reset: function () { elements.fromDate.value = ''; elements.toDate.value = ''; },
            focus: function () {}
        };
        return elements[id];
    },
    addEventListener: function (type, fn) { if (type === 'DOMContentLoaded') domReady = fn; }
};
var setTimeout = function () { return 1; };
var clearTimeout = function () {};
var AbortController = function () { this.signal = {}; this.abort = function () {}; };
var requests = [];
var fetch = function (url, options) {
    var next = requests.shift();
    if (!next) return Promise.reject(new Error('Missing mock response'));
    if (next instanceof Error) return Promise.reject(next);
    if (next.then) return next;
    return Promise.resolve({ok: true, text: function () { return Promise.resolve(typeof next === 'string' ? next : JSON.stringify(next)); }});
};
var count = 0;
function assert(condition, message) { if (!condition) throw new Error(message); count++; }
function equal(actual, expected, message) { assert(actual === expected, message + ': ' + actual + ' !== ' + expected); }
function expectThrow(fn, message) { var threw = false; try { fn(); } catch (_) { threw = true; } assert(threw, message); }
async function rejects(fn, message) { var threw = false; try { await fn(); } catch (_) { threw = true; } assert(threw, message); }

['fromDate', 'toDate'].forEach(function(id){document.getElementById(id);});
// `load` là hàm sẵn có của JavaScriptCore.
load('js/order-data.js');
load('js/order-api.js');
load('js/order-list.js');
load('js/order.js');
load('js/printorder.js');

async function run() {
    var app = window.InvoiceApp;
    var D = app.Data;
    equal(D.parseDate('3/11/2026'), '2026-11-03', 'Ngày Việt Nam không bị đảo tháng');
    equal(D.parseDate('2026-11-03'), '2026-11-03', 'Ngày ISO');
    equal(D.parseDate('2026-11-02T18:00:00Z'), '2026-11-03', 'Timestamp theo ngày Việt Nam');
    equal(D.parseDate('', 'HD031120260002'), '2026-11-03', 'Ngày thiếu suy từ mã đơn cũ');
    equal(D.parseDate('31/02/2026'), '', 'Không chấp nhận ngày không tồn tại');
    equal(D.parseDate('2026-02-30T00:00:00Z'), '', 'Không tự đổi ngày ISO lỗi sang tháng sau');
    equal(D.parseDate('29/02/2024'), '2024-02-29', 'Năm nhuận');
    equal(D.money('-250.000 đ'), -250000, 'Giữ dấu âm tiền trả dư');
    equal(D.money('1.200.000'), 1200000, 'Tiền Việt Nam');
    equal(D.money('250,25 đ'), 250.25, 'Không nhân sai phần thập phân');
    equal(D.money('90000.00'), 90000, 'Tiền thập phân từ máy chủ');
    var fractional = D.normalizeOrder({id:'HD031120260001',items:[{name:'Cát',qty:0.25,price:1001}]});
    equal(fractional.total, 250, 'Làm tròn đồng khi số lượng lẻ');
    equal(D.money(D.formatMoney(fractional.total)), fractional.total, 'Tiền lưu/hiển thị cùng giá trị');
    var orders = [
        {id:'HD011120260001', date:'1/11/2026', total:'100.000 đ', paid:'20.000', debt:'80.000 đ'},
        {id:'HD021120260001', date:'2/11/2026', total:200000, paid:200000, debt:0},
        {id:'HD031120260001', date:'', total:300000, paid:400000, debt:-100000},
        {id:'legacy', date:'', customer:'Khách cũ', total:400000, paid:0}
    ].map(D.normalizeOrder);
    equal(D.filterOrders(orders).length, 4, 'Mặc định có cả hóa đơn chưa rõ ngày');
    equal(D.filterOrders(orders, '2026-11-01', '2026-11-03').length, 3, 'Bao gồm cả đầu/cuối, loại ngày chưa rõ');
    equal(D.filterOrders(orders, '2026-11-02', '2026-11-02').length, 1, 'Lọc cùng một ngày');
    equal(D.filterOrders(orders, '', '2026-11-02').length, 2, 'Chỉ ngày kết thúc');
    equal(D.filterOrders(orders, '2026-11-02', '').length, 2, 'Chỉ ngày bắt đầu');
    equal(D.filterOrders(orders, '2027-01-01', '').length, 0, 'Khoảng không có hóa đơn');
    expectThrow(function () { D.filterOrders(orders, '2026-11-04', '2026-11-01'); }, 'Chặn khoảng ngược');
    equal(D.sortOrders(orders)[0].id, 'HD031120260001', 'Mới nhất trước');
    equal(D.sortOrders(orders).at(-1).id, 'legacy', 'Ngày không rõ xếp cuối');
    equal(D.escapeHtml('<img onerror="x">'), '&lt;img onerror=&quot;x&quot;&gt;', 'Dữ liệu được escape');
    equal(D.normalizeOrder({items:'[{"name":"Xi măng","qty":2,"price":90000}]'}).total, 180000, 'Items JSON từ Sheet');
    equal(D.normalizeOrder({items:[{name:'Xi măng',qty:2,unit:'bao',price:90000}]}).items[0].unit, 'bao', 'Giữ đơn vị tính từ CHITIET_HD');
    equal(D.normalizeOrder({items:[{name:'Xi măng',qty:2,price:90000}]}).items[0].unit, '', 'Đơn cũ không có ĐVT vẫn đọc được');

    requests.push({lastId:'HD031120260002'});
    await rejects(function () { return app.API.list(); }, 'Không biến lastId thành danh sách rỗng');
    requests.push({orders:[]});
    equal((await app.API.list()).length, 0, 'Danh sách thật rỗng');
    requests.push({success:false,error:'write failed'});
    await rejects(function () { return app.API.save({id:'draft'}); }, 'Lỗi ứng dụng dù HTTP 200');
    for (var ambiguous of [{}, [], {lastId:'HD031120260002'}]) {
        requests.push(ambiguous);
        await rejects(function () { return app.API.save({id:'draft'}); }, 'Không báo đã lưu khi chưa được xác nhận');
    }
    requests.push({status:'success'});
    equal((await app.API.save({id:'draft'})).id, 'draft', 'Tương thích xác nhận thành công');
    requests.push('Success');
    equal((await app.API.save({id:'draft'})).id, 'draft', 'Tương thích phản hồi text');
    requests.push({order:{id:'official'}});
    equal((await app.API.save({id:'draft'})).id, 'official', 'Mã chính thức do máy chủ cấp');
    requests.push({status:'success',id:'HD031120260099'});
    var savedOfficial = await app.API.save({id:'HD031120260001',customer:'Khách hàng',items:[{name:'Cát',qty:1,unit:'m³',price:100000}]});
    equal(savedOfficial.id, 'HD031120260099', 'Dùng chính xác mã do doPost hiện tại trả về');
    equal(savedOfficial.items[0].unit, 'm³', 'Phản hồi chỉ có id giữ đủ mặt hàng vừa nhập');
    requests.push('API OK');
    await rejects(function () { return app.API.list(); }, 'doGet cũ trả API OK chưa phải danh sách');

    app.notify = function () {};
    requests.push({orders:orders});
    app.List.init();
    // Một yêu cầu riêng giúp chờ lần tải cuối mà không phụ thuộc timer.
    requests.push({orders:orders});
    await app.List.load();
    equal(app.List.getOrders().length, 4, 'Đọc toàn bộ lịch sử');
    assert(elements.orderList.innerHTML.includes('Khách cũ'), 'Đơn cũ có trong bảng');
    elements.fromDate.value = '2026-11-02'; elements.toDate.value = '2026-11-03';
    elements.filterForm.listeners.submit({preventDefault:function(){}});
    equal(elements.statsCount.textContent, '2', 'Thống kê theo bộ lọc');
    equal(D.money(elements.statsTotal.textContent), 500000, 'Tổng theo bộ lọc');
    equal(D.money(elements.statsDebt.textContent), -100000, 'Công nợ có trả dư');
    elements.fromDate.value = '2026-11-04'; elements.toDate.value = '2026-11-01';
    elements.filterForm.listeners.submit({preventDefault:function(){}});
    assert(!elements.filterError.hidden, 'Hiện lỗi ngày ngược');
    equal(elements.statsCount.textContent, '2', 'Ngày sai không làm mất kết quả');
    elements.resetFilters.listeners.click();
    equal(elements.statsCount.textContent, '4', 'Xem tất cả phục hồi cả hóa đơn không rõ ngày');
    var unsafe = {id:'HD041120260001',date:'4/11/2026',customer:'<img src=x onerror=x>',items:[{name:'<script>x</script>',qty:1,unit:'bao<svg>',price:10}], total:10};
    app.List.remember(unsafe);
    equal(app.List.getOrders().length, 5, 'Đơn vừa lưu hiện ngay');
    assert(!elements.orderList.innerHTML.includes('<img src=x'), 'Escape khách hàng trong bảng');
    assert(elements.orderList.innerHTML.includes('&lt;script&gt;'), 'Escape tên hàng trong bảng');
    assert(elements.orderList.innerHTML.includes('bao&lt;svg&gt;'), 'Hiển thị và escape đơn vị tính trong bảng');
    requests.push(new Error('Mất mạng'));
    await app.List.load();
    equal(app.List.getOrders().length, 5, 'Tải lỗi giữ danh sách');
    assert(!elements.listStatus.hidden, 'Tải lỗi có thông báo');
    requests.push({orders:[...orders, {...unsafe, customer:'Tên từ máy chủ'}]});
    await app.List.load();
    equal(app.List.getOrders().length, 5, 'Không trùng đơn khi tải lại');
    equal(app.List.getOrders()[0].customer, 'Tên từ máy chủ', 'Dữ liệu chính thức thay bản tạm');
    // Phản hồi cũ đến muộn không được ghi đè lần làm mới sau.
    var resolveOlder;
    requests.push(new Promise(function(resolve){resolveOlder=resolve;}));
    var earlier = app.List.load();
    requests.push({orders:[unsafe]});
    await app.List.load();
    resolveOlder({ok:true,text:function(){return Promise.resolve(JSON.stringify({orders:orders}));}});
    await earlier;
    equal(app.List.getOrders().length, 1, 'Chặn race khi làm mới');
    var printed = false;
    window.print = function(){ printed = true; };
    app.Print.print(unsafe);
    assert(printed, 'Mở in');
    equal(elements.p_date.textContent, 'Ngày 04/11/2026', 'In ngày hóa đơn, không lấy ngày hôm nay');
    assert(elements.p_table.innerHTML.includes('&lt;script&gt;'), 'Escape mặt hàng khi in');
    assert(elements.p_table.innerHTML.includes('<td>bao&lt;svg&gt;</td>'), 'Cột ĐVT được in và escape');
    app.Print.print(savedOfficial);
    equal(elements.p_id.textContent, 'HD031120260099', 'Bản in dùng mã chính thức trả về');
    print('PASS: ' + count + ' invoice behavior checks');
}
run().catch(function(error){ print('FAIL: ' + error.message + '\n' + error.stack); quit(1); });
